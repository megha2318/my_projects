List images = [
  "https://im.indiatimes.in/media/content/2015/Jan/singapore-marhsall-university_1421316697_725x725.jpg",
  "https://i.pinimg.com/564x/93/ac/71/93ac7133bff5bcb546c04853a396e9f6.jpg",
  "https://www.myglobalviewpoint.com/wp-content/uploads/2020/01/Zermatt-town-in-Switzerland.jpg",
  "https://media.cntraveler.com/photos/611bafebd713cfe783511f6c/master/w_1600%2Cc_limit/Lofoten-Islands-_GettyImages-583610815.jpg",
  "https://i.pinimg.com/736x/c7/38/a5/c738a5094dd25ee16474f7033fc125ab.jpg",
  "https://i.pinimg.com/564x/a0/b3/7b/a0b37b652ee9bf6dfc91771a477a82f5.jpg",
  "https://i.pinimg.com/736x/4f/72/66/4f7266d6ecd16b702538bef64ea0ea69.jpg",
  "https://i.pinimg.com/564x/4c/39/f4/4c39f48dab28740de1b921ee7b20cbe3.jpg",
  "https://i2.wp.com/handluggageonly.co.uk/wp-content/uploads/2015/05/Paris.jpg?resize=1000%2C563&ssl=1",
];

List names = [
  "Singapore",
  "Le Sirenuse",
  "Zermatt Switzerland",
  "Lofoten Islands",
  "Lava and Ice",
  "Dark Cottagecore",
  "Algonquin Park",
  "Maldives",
  "Afil Tower",
];