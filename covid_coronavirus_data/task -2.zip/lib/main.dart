import 'package:covid_coronavirus_data/screens/home_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(
    const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomePage(),
  ),);
}
