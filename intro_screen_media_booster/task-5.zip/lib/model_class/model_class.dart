List introImages = [
  "https://5.imimg.com/data5/SF/BT/MY-9965178/recharge-business-with-optisol-develop-your-android-app-500x500.png",
  "https://www.claruscommerce.com/wp-content/uploads/2016/09/CC-blog-Millennial-icon1.png",
  "https://p.kindpng.com/picc/s/301-3017127_sales-and-promotions-png-transparent-png.png",
  "https://unamo.com/blog/wp-content/uploads/2014/08/How-I-Successfully-Included-Storytelling-in-my-Articles-640x250.png",
];