import 'package:flutter/material.dart';

Color whiteColor = Colors.white;
Color bgColor = Color(0xff0f1337);
Color darkGreyColor = Color(0xff272c4e);
Color lightWhiteColor = Color(0xffafb4d3);
Color deepPinkColor = Color(0xfff8016d);
Color deepPurpleColor = Color(0xff652e63);
Color lightBlackColor = Color(0xff111530);