String bmiCalculator = "BMI CALCULATOR";
String male = "MALE";
String female = "FEMALE";
String heightS = "HEIGHT";
String weight = "WEIGHT";
String age = "AGE";
String normalWeight = "NORMAL WEIGHT";
String underWeight = "UNDER WEIGHT";
String overWeight = "OVER WEIGHT";
String normal = "normal";
String under = "under";
String over = "over";
String goodJob = "Good Job";
String weit = "weight";

bool isAnimation = false;