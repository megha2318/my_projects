import 'package:flutter/material.dart';

Color greyColor = Colors.grey;
Color whiteColor = Colors.white;
Color bgColor = Color(0xff3a3860);
Color lightBlueColor = Color(0xff40426f);