class AppRoutes{
  static String audioPlayerScreen = "/audioPlayerScreen";
  static String homeScreen = "/";
  static String audioScreen = "/audioScreen";
  static String fileAudioScreen = "/fileAudioScreen";
}

