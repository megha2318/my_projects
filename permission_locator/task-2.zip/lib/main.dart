import 'package:flutter/material.dart';
import 'package:permission_locator/screens/home_screen.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomePage(),
  ));
}

