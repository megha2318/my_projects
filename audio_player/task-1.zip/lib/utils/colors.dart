import 'package:flutter/material.dart';

Color blackColor = Colors.black;
Color whiteColor = Colors.white;
Color greyColor = Colors.grey;
