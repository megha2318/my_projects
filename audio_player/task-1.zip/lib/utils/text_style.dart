import 'package:flutter/material.dart';

TextStyle whiteTxt = const TextStyle(
  color: Colors.white,
);
TextStyle whiteTxt18 = const TextStyle(
  color: Colors.white,
  fontSize: 18,

);